﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class UpdateForm : Form
    {
        Commons comm;
        private Form1 form;
        public UpdateForm()
        {
            InitializeComponent();
            Load += UpdateForm_Load;
        }

        private void UpdateForm_Load(object sender, EventArgs e)
        {
            comm = new Commons(this);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Close();

        }
    }
}
