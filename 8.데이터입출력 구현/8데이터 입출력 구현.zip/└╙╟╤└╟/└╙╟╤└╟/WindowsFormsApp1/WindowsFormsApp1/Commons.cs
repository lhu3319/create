﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    class Commons
    {
        private MySqlConnection conn;
        private Form1 form;
        private Form2 form2;
        private UpdateForm form3;
        public Commons(Form form)
        {
             this.form = (Form1)form;
            Connect();

        }
        public Commons (Form2 form2)
        {
            this.form2 = (Form2)form2;
            Connect();
        }
        public Commons (UpdateForm form3)
        {
            this.form3 = (UpdateForm)form3;
            Connect();
        }

            public void Connect()
        {
            conn = new MySqlConnection();
            string host = "192.168.3.192";
            string user = "root";
            string password = "1234";
            string db = "gdc";

            conn.ConnectionString = string.Format(@"server={0};user={1};password={2};database={3}", host, user, password, db);
            try
            {
                conn.Open();
            }
            catch
            {
                MessageBox.Show("DB 오류");
            }
        }
        public void Read() // 읽기
        {
            try
            {
                MySqlCommand comm = new MySqlCommand("sele_main", conn);
                comm.CommandType = CommandType.StoredProcedure;
                MySqlDataReader sdr = comm.ExecuteReader();
                form.listView1.Items.Clear();
                while (sdr.Read())
                {
                    string[] arr = new string[4];
                    for (int i = 0; i < sdr.FieldCount; i++)
                    {
                        arr[i] = sdr.GetValue(i).ToString();
                    }
                    form.listView1.Items.Add(new ListViewItem(arr));
                }
                sdr.Close();
                //conn.Close();
            }
            catch
            {
                MessageBox.Show("연결 실패");
            }
        }
        public void CUD(string commandText) // 추가(name,age)/수정(no,name,age)/삭제(no)
        {
            switch(commandText)
            {
                case "write2":
                    try
                    {
                        //conn.Open();
                        MySqlCommand comm = new MySqlCommand(commandText, conn);
                        comm.CommandType = CommandType.StoredProcedure;

                        string head = form2.textBox4.Text;
                        string contents = form2.textBox1.Text;
                        string id = form2.textBox2.Text;
                        string pass = form2.textBox3.Text;

                        comm.Parameters.AddWithValue("_head", head);
                        comm.Parameters.AddWithValue("_contents", contents);
                        comm.Parameters.AddWithValue("_id", id);
                        comm.Parameters.AddWithValue("_pass", pass);

                        comm.ExecuteNonQuery();
                        //conn.Close();
                        MessageBox.Show("추가하였습니다..");
                       
                    }
                    catch
                    {
                        MessageBox.Show("실패하였습니다.");
                    }
                    
                    break;
                case "total_plus":
                    try
                    {
                        MySqlCommand comm = new MySqlCommand("total_plus", conn);
                        comm.CommandType = CommandType.StoredProcedure;
                        
                    }
                    catch
                    {

                    }
                    break;
            }
           

        }



    }
}
