﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Commons comm;
        public Form1()
        {
            InitializeComponent();
            Load += Form1_Load;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comm = new Commons(this);
            listView1.MouseClick += lv1;
            listView1.FullRowSelect = true;
            comm.Read();
        }

        private void lv1(object o, EventArgs e)
        {
            comm = new Commons(this);
            comm.CUD("total_plus");
            ListView lv = (ListView)o;

            UpdateForm uf = new UpdateForm();
            uf.ShowDialog();

            ListView.SelectedListViewItemCollection slv = lv.SelectedItems;
            for (int i = 0; i < slv.Count; i++)
            {
                ListViewItem item = slv[i];
                uf.label1.Text = item.SubItems[0].Text;
                uf.textBox1.Text = item.SubItems[i].Text;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            UpdateForm uf = new UpdateForm();
            f2.ShowDialog();

        }


    }
}
