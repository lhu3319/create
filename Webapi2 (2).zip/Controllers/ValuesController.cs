﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Webapi2.Modules;
using System.Collections;

namespace Webapi2.Controllers
{
    [ApiController]
    public class ValuesController : ControllerBase
    {
       
        Maria Madb;

        [Route("mc_select")]
        [HttpGet]
        public ActionResult<ArrayList> mc_select()
        {
            Console.WriteLine("select");

            Madb = new Maria();

            MySqlDataReader sdr = Madb.Reader("sp_MenuCategory_Select");
            ArrayList list = new ArrayList();
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            Madb.ReaderClose(sdr);
            Madb.Close();
            return list;
        }
        [Route("mn_select")]
        [HttpPost]
        public ActionResult<ArrayList> Select([FromForm] string bNo)
        {

            Maria Madb = new Maria();
            Hashtable ht = new Hashtable();
            ht.Add("_bNo", bNo);

            Console.WriteLine(bNo);
            MySqlDataReader sdr = Madb.Reader2("sp_Menu_Select_M", ht);

            ArrayList list = new ArrayList();
            while (sdr.Read())
            {

                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();

                }
                list.Add(arr);
            }
            Madb.ReaderClose(sdr);
            Madb.Close();

            return list;
        }

        [Route("mc_insert")]
        [HttpPost]
        public ActionResult<string> mc_insert([FromForm] string mc_Name)
        {
            string param = string.Format("  {0}  ", mc_Name);
            Console.WriteLine("  insert" + param);
            Hashtable ht = new Hashtable();
            ht.Add("_mc_Name", mc_Name);

            Madb = new Maria();

            if (Madb.NonQuery("sp_MenuCategory_Insert", ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
             Madb.Close();
        }

        [Route("mn_insert")]
        [HttpPost]
        public ActionResult<string> mn_insert([FromForm] string m_bNo, [FromForm] string m_Name, [FromForm] string m_Price)
        {
            string param = string.Format("  {0}  :  {1}  :  {2} ", m_bNo, m_Name, m_Price);
            Console.WriteLine("  insert" + param);
            Hashtable ht = new Hashtable();
            ht.Add("_bNo", m_bNo);
            ht.Add("_m_Name", m_Name);
            ht.Add("_m_Price", m_Price);

            Madb = new Maria();
            if (Madb.NonQuery("sp_Menu_Insert_M", ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
             Madb.Close();
        }

        [Route("mc_update")]
        [HttpPost]
        public ActionResult<string> mc_update([FromForm]string mc_No, [FromForm] string mc_Name)
        {
            string param = string.Format("  {0} , {1} , ", mc_No, mc_Name);
            Console.WriteLine("  update  " + param);
            Hashtable ht = new Hashtable();
            ht.Add("_mc_No", mc_No);
            ht.Add("_mc_Name", mc_Name);
            Madb = new Maria();
            if (Madb.NonQuery("sp_MenuCategory_Update", ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
             Madb.Close();
        }

        [Route("mn_update")]
        [HttpPost]
        public ActionResult<string> mn_update([FromForm]string m_Sort, [FromForm] string m_Name, [FromForm] string m_Price, [FromForm] string m_bNo)
        {
            string param = string.Format("  {0} , {1} , {2} , {3}  ", m_Sort, m_Name, m_Price, m_bNo);
            Console.WriteLine("  update  " + param);
            Hashtable ht = new Hashtable();
            ht.Add("_m_Sort", m_Sort);
            ht.Add("_m_Name", m_Name);
            ht.Add("_m_Price", m_Price);
            ht.Add("_m_bNo", m_bNo);
            Madb = new Maria();
            if (Madb.NonQuery("sp_Menu_Update_M", ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
             Madb.Close();
        }
        [Route("mc_delete")]
        [HttpPost]
        public ActionResult<string> mc_delete([FromForm]string mc_No)
        {
            string param = string.Format("  {0}  ", mc_No);
            Console.WriteLine("   delete  " + param);
            Hashtable ht = new Hashtable();
            ht.Add("_mc_No", mc_No);
            Madb = new Maria();
            if (Madb.NonQuery("sp_MenuCategory_Delete", ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
                 Madb.Close();
        }
        [Route("mn_delete")]
        [HttpPost]
        public ActionResult<string> mn_delete([FromForm]string m_bNo, [FromForm]string m_Sort)
        {
            string param = string.Format("  {0}  :  {1}  ", m_bNo , m_Sort);
            Console.WriteLine("   delete  " + param);
            Hashtable ht = new Hashtable();
             ht.Add("_m_bNo", m_bNo);
            ht.Add("_m_Sort", m_Sort);
            Madb = new Maria();
            if (Madb.NonQuery("sp_Menu_Delete_M", ht)) 
            {
                return "1";
            }
            else
            {
                return "0";
            }
             Madb.Close();

        }

        [Route("SI_insert_Pos")]
        [HttpPost]
        public ActionResult<string> SI_insert([FromForm] string ps_Id, [FromForm] string ps_Rank, [FromForm] string ps_passwd, [FromForm] string ps_code, [FromForm] int result)
        {

            string param = string.Format("  {0} , {1} , {2} , {3}  ", ps_Id, ps_Rank, ps_passwd, ps_code);
            Console.WriteLine("  insert  " + param);
            Hashtable ht = new Hashtable();
            ht.Add("_ps_Id", ps_Id);
            ht.Add("_ps_Rank", ps_Rank);
            ht.Add("_ps_passwd", ps_passwd);
            ht.Add("_ps_code", ps_code);
            ht.Add("_result", result);

            Madb = new Maria();

            if (Madb.NonQuery("sp_Pos_SignIn_Insert", ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
             Madb.Close();
        }

        [Route("SI_select_Pos_Id")]
        [HttpGet]
        public ActionResult<string> IdPass_Id()
        {
            Madb = new Maria();

            MySqlDataReader sdr = Madb.Reader("sp_Pos_SignIn_Select_Id");

            while (sdr.Read())
            {
                return sdr.GetValue(0).ToString();

            }
            Madb.ReaderClose(sdr);
             Madb.Close();
            return "";
        }

        [Route("SI_select_Pos_Pass")]
        [HttpGet]
        public ActionResult<string> IdPass_Pass()
        {
            Madb = new Maria();

            MySqlDataReader sdr = Madb.Reader("sp_Pos_SignIn_Select_Pass");

            while (sdr.Read())
            {
                return sdr.GetValue(0).ToString();

            }
            Madb.ReaderClose(sdr);
             Madb.Close();
            return "";
        }

        [Route("sp_Pos_Count")]
        [HttpGet]
        public ActionResult<ArrayList> sp_Pos_Count()
        {
            Console.WriteLine("select");

            Madb = new Maria();

            MySqlDataReader sdr = Madb.Reader("sp_Pos_Count");
            ArrayList list = new ArrayList();
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            Madb.ReaderClose(sdr);
             Madb.Close();
            return list;
        }

        [Route("F3_total_day")]
        [HttpGet]
        public ActionResult<string> F3_total_day()
        {
            Madb = new Maria();

            MySqlDataReader sdr = Madb.Reader("sp_total_day");

            while (sdr.Read())
            {
                Console.WriteLine(sdr.GetValue(0).ToString());
                return sdr.GetValue(0).ToString();

            }
            Madb.ReaderClose(sdr);
             Madb.Close();
            return "";
        }



        //------------------------------한의--------------------------------


        [Route("cm_init")]
        [HttpGet]
        public ActionResult<ArrayList> select()
        {
            Console.WriteLine("select");
            Maria maria = new Maria();
            MySqlDataReader sdr = maria.Reader("select_CM_init");
            ArrayList list = new ArrayList();
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            maria.ReaderClose(sdr);
            maria.Close();
            return list;
        }

        [Route("sel_date")]
        [HttpPost]
        public ActionResult<ArrayList> Rank([FromForm] string spName, [FromForm] string start, [FromForm] string end)
        {
            Console.WriteLine("spName : {0}, start : {1}, end : {2}", spName, start, end);
            Hashtable ht = new Hashtable();

            ht.Add("_start", start);
            ht.Add("_end", end);
            Maria maria = new Maria();
            MySqlDataReader sdr = maria.Reader2(spName, ht);
            Console.WriteLine("성공");
            ArrayList list = new ArrayList();
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    Console.WriteLine(sdr.GetValue(i).ToString());
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            maria.ReaderClose(sdr);
            maria.Close();
            Console.WriteLine("asd : {0}", list.Count);
            return list;
        }

        [Route("sel_rank")]
        [HttpPost]
        public ActionResult<ArrayList> name([FromForm] string spName, [FromForm] string start, [FromForm] string end)
        {
            Console.WriteLine("spName : {0}, start : {1}, end : {2}", spName, start, end);
            Hashtable prc = new Hashtable();

            prc.Add("_start", start);
            prc.Add("_end", end);
            Maria maria = new Maria();
            MySqlDataReader sdr = maria.Reader2(spName, prc);
            Console.WriteLine("성공");
            ArrayList list = new ArrayList();
            while (sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    Console.WriteLine(sdr.GetValue(i).ToString());
                    ht.Add(sdr.GetName(i), sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            maria.ReaderClose(sdr);
            maria.Close();
            Console.WriteLine("asd : {0}", list.Count);
            return list;
        }

        [Route("insert_CM")]
        [HttpGet]
        public ActionResult<string> Insert()
        {

            Maria maria = new Maria();
            string result = "";
            if (maria.NonQuery2("insert_CM"))
            {
                result = "Success";
            }
            else
            {
                result = "Fail";
            }
            maria.Close();
            return result;
        }
        //--------------------------------남규---------------------------------//
        [Route("select")]
        [HttpPost]
        public ActionResult<ArrayList> select([FromForm] string spName, [FromForm] string param)
        {
            Console.WriteLine("spName : {0}, param : {1}",spName, param);
            Hashtable ht = new Hashtable();
            if(!String.IsNullOrEmpty(param)){
                string[] str = param.Split(":");
                ht.Add(str[0], str[1]);
               
                Console.WriteLine("11111");
            }
            
            Maria db = new Maria(); 
            MySqlDataReader sdr = db.Reader2(spName, ht);
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    Console.WriteLine(sdr.GetValue(i).ToString());
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            db.ReaderClose(sdr);
            db.Close();
            Console.WriteLine("asd : {0}",list.Count.ToString());
            return list;
        }

        [Route("sp_update")]
        [HttpPost]
        public ActionResult<string> update([FromForm] string spName,[FromForm] string tNo, [FromForm] string mNo,[FromForm] string oCount)
        {
           
            Console.WriteLine("spName : {0}, mNo : {1}, tNo : {2}, oCount : {3}",spName, mNo, tNo,oCount);
            Hashtable ht = new Hashtable();
            ht.Add("_mNo",mNo);
            ht.Add("_tNo",tNo);
            ht.Add("_oCount",oCount);
            Maria db = new Maria();

            System.Console.WriteLine(db.NonQuery("sp_update",ht));
            if(db.NonQuery(spName,ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
            db.Close();
        }

        [Route("sp_delete")]
        [HttpPost]
        public ActionResult<string> delete([FromForm] string spName,[FromForm] string tNo)
        {
            Console.WriteLine("spName : {0}, tNo : {1}",spName, tNo);
            
            Hashtable ht = new Hashtable();
            ht.Add("_tNo",tNo);
           
            Maria db = new Maria();
            if(db.NonQuery(spName,ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
            db.Close();
        }

        [Route("sp_insert")]
        [HttpPost]
        public ActionResult<string> sp_insert([FromForm] string spName, [FromForm] string mNo, [FromForm] string tNo,[FromForm] string oCount)
        {
            Console.WriteLine("spName : {0}, mNo : {1}, tNo : {2}, oCount : {3}",spName, mNo, tNo,oCount);
            Hashtable ht = new Hashtable();
           
            ht.Add("_mNo",mNo);
            ht.Add("_tNo",tNo);
            ht.Add("_oCount",oCount);
            Maria db = new Maria(); 
           if(db.NonQuery(spName,ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
            db.Close();
        }

        [Route("sp_list_delete")]
        [HttpPost]
        public ActionResult<string> sp_list_delete([FromForm] string spName,[FromForm] string tNo,[FromForm] string mNo)
        {
            Console.WriteLine("spName : {0}, tNo : {1}, mName = {2}",spName, tNo, mNo);
            
            Hashtable ht = new Hashtable();
            ht.Add("_tNo",tNo);
            ht.Add("_mNo",mNo);
            Maria db = new Maria();
            if(db.NonQuery(spName,ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
            db.Close();
        }
    }
}
