/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Webapi2.Modules;
using System.Collections;

namespace Webapi2.Controllers
{
    [ApiController]
    public class MarController : ControllerBase
    {
        [Route("cm_init")]
        [HttpGet]
        public ActionResult<ArrayList> select()
        {
            Console.WriteLine("select");
            Maria db = new Maria();
            MySqlDataReader sdr = db.Reader("select_CM_init");
            ArrayList list = new ArrayList();
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            db.ReaderClose(sdr);
            db.Close();
            return list;
        }

        [Route("sel_date")]
        [HttpPost]
        public ActionResult<ArrayList> Rank([FromForm] string spName, [FromForm] string start, [FromForm] string end)
        {
            Console.WriteLine("spName : {0}, start : {1}, end : {2}",spName, start,end);
            Hashtable ht = new Hashtable();

            ht.Add("_start",start);
            ht.Add("_end",end);
            Maria db = new Maria(); 
            MySqlDataReader sdr = db.Reader2(spName, ht);
            Console.WriteLine("성공");
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {     
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    Console.WriteLine(sdr.GetValue(i).ToString());
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            db.ReaderClose(sdr);
            db.Close();
            Console.WriteLine("asd : {0}",list.Count);
            return list;
        }

        [Route("sel_rank")]
        [HttpPost]
        public ActionResult<ArrayList> name([FromForm] string spName, [FromForm] string start, [FromForm] string end)
        {
            Console.WriteLine("spName : {0}, start : {1}, end : {2}",spName, start,end);
            Hashtable prc = new Hashtable();

            prc.Add("_start",start);
            prc.Add("_end",end);
            Maria db = new Maria(); 
            MySqlDataReader sdr = db.Reader2(spName, prc);
            Console.WriteLine("성공");
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {     
                Hashtable ht = new Hashtable();
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    Console.WriteLine(sdr.GetValue(i).ToString());
                    ht.Add(sdr.GetName(i),sdr.GetValue(i).ToString());
                }
                list.Add(ht);
            }
            db.ReaderClose(sdr);
            db.Close();
            Console.WriteLine("asd : {0}",list.Count);
            return list;
        }

       [Route("insert_CM")]
        [HttpGet]
        public ActionResult<string> Insert()
        {
           
            Maria db = new Maria();
            string result = "";
            if(db.NonQuery2("insert_CM")){
                result = "Success";
            }
            else{
                result = "Fail";
            }
            db.Close();
            return result;
        }
         
    }
}

*/