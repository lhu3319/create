

#!/bin/sh
###############################################################
# Service > systemd > dotnet.service
# Sample Project > /root
# ip Change > 192.168.3."You linux ip"
# MariaDB > user(root)/password(test) > table(test.board)
###############################################################
# 1. GitHub Repository Download
if [ -d /root/Project] ; then
        rm -rf /root/Project
fi

git clone https://github.com/lhu3319/Project.git
# 2. Project Build


cd Project

dotnet build

# 3. Service Shutdown
systemctl stop dotnet.service

# 4. Project Publish
dotnet publish


# 5. Service Run

dotnet run &
systemctl start dotnet.service

exit 0
###############################################################




















 
