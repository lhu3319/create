﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using System.Collections;
using Newtonsoft.Json.Linq;

namespace _20181207.Modules
{
    class web
    {
        public void Connect()
        {
            WebClient client = new WebClient(); // 웹 접속 객체 생성
            NameValueCollection data = new NameValueCollection();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)"); // 웹 호출 시 보낸쪽 정보 설정
            client.Encoding = Encoding.UTF8; // UTF-8 설정 하여 한글 처리하기

            string url = "http://192.168.3.28:5000/api/Select";

            string method = "POST";


            byte[] result = client.UploadValues(url, method, data);
            string strResult = Encoding.UTF8.GetString(result);
            ArrayList strJ = JsonConvert.DeserializeObject<ArrayList>(strResult);
            for (int i = 0; i < strJ.Count; i++)
            {
                JObject jo = (JObject)strJ[i];
                foreach (JProperty jp in jo.Properties())
                {
                    Console.WriteLine("{0} : {1}", jp.Name, jp.Value);
                }

            }

        }
    }
}
