-- --------------------------------------------------------
-- 호스트:                          192.168.3.151
-- 서버 버전:                        10.1.38-MariaDB-0ubuntu0.18.04.1 - Ubuntu 18.04
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  9.5.0.5295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Project 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `Project` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `Project`;

-- 프로시저 Project.add_Addr 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `add_Addr`(in gu varchar(10),in dong varchar(50),in full varchar(300), in road varchar(50),in fullr varchar(300))
begin 
insert into Address (Gu_name,Dong_name,Full_name,Road_name,FullR_name)
				values (gu,dong,full,road,fullr);
	end//
DELIMITER ;

-- 프로시저 Project.insert_info 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `insert_info`(
	IN `_Name` varchar(10),
	IN `_Phone` varchar(20),
	IN `_Number` varchar(20),
	IN `_Addr` varchar(100),
	IN `_Home` varchar(10),
	IN `_Elve` varchar(1),
	IN `_Out` varchar(30),
	IN `_Memo` varchar(100)
)
begin
	insert into Person (pName,phNumber,pNumber,pAddr,pHome,pElve,Outdate,pMemo)values (_Name,_Phone,_Number,_Addr,_Home,_Elve,_Out,_Memo);
	commit;
end//
DELIMITER ;

-- 프로시저 Project.insert_Product 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `insert_Product`(
	IN `_Phone` INT,
	IN `_iNo` INT,
	IN `_cnt` INT
,
	IN `_date` VARCHAR(50)
)
begin
	insert into Orderlist (pNo,iNo,cnt,outdate)values
	 ((select pNo from Person where phNumber = _Phone),_iNo,_cnt,_date);
	commit;
end//
DELIMITER ;

-- 테이블 Project.Orderlist 구조 내보내기
CREATE TABLE IF NOT EXISTS `Orderlist` (
  `oNo` int(11) NOT NULL AUTO_INCREMENT,
  `pNo` int(11) NOT NULL,
  `iNo` int(11) NOT NULL,
  `cnt` int(11) NOT NULL DEFAULT '0',
  `outdate` datetime NOT NULL,
  `dleYn` varchar(1) NOT NULL DEFAULT 'N',
  `regDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`oNo`),
  KEY `Order_list_2` (`iNo`),
  KEY `Order_list_1` (`pNo`),
  CONSTRAINT `Order_list_1` FOREIGN KEY (`pNo`) REFERENCES `Person` (`pNo`),
  CONSTRAINT `Order_list_2` FOREIGN KEY (`iNo`) REFERENCES `Product` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- 테이블 데이터 Project.Orderlist:~8 rows (대략적) 내보내기
/*!40000 ALTER TABLE `Orderlist` DISABLE KEYS */;
INSERT INTO `Orderlist` (`oNo`, `pNo`, `iNo`, `cnt`, `outdate`, `dleYn`, `regDate`) VALUES
	(1, 1, 6, 1, '0000-00-00 00:00:00', 'N', '2019-03-20 06:06:12'),
	(2, 1, 35, 1, '0000-00-00 00:00:00', 'N', '2019-03-20 06:06:12'),
	(3, 1, 36, 1, '0000-00-00 00:00:00', 'N', '2019-03-20 06:06:12'),
	(4, 1, 37, 1, '0000-00-00 00:00:00', 'N', '2019-03-20 06:06:12'),
	(5, 1, 38, 1, '0000-00-00 00:00:00', 'N', '2019-03-20 06:06:12'),
	(6, 1, 46, 1, '0000-00-00 00:00:00', 'N', '2019-03-20 06:06:12'),
	(7, 1, 21, 2, '0000-00-00 00:00:00', 'N', '2019-03-20 07:13:15'),
	(8, 1, 22, 6, '0000-00-00 00:00:00', 'N', '2019-03-20 07:13:15'),
	(9, 2, 20, 2, '2019-03-28 00:00:00', 'N', '2019-03-20 07:39:01');
/*!40000 ALTER TABLE `Orderlist` ENABLE KEYS */;

-- 테이블 Project.Person 구조 내보내기
CREATE TABLE IF NOT EXISTS `Person` (
  `pNo` int(11) NOT NULL AUTO_INCREMENT,
  `pName` varchar(10) NOT NULL,
  `phNumber` varchar(20) NOT NULL,
  `pNumber` varchar(20) DEFAULT NULL,
  `pAddr` varchar(100) NOT NULL,
  `pHome` varchar(10) NOT NULL,
  `pElve` varchar(1) NOT NULL,
  `Outdate` varchar(30) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pMemo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pNo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 테이블 데이터 Project.Person:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `Person` DISABLE KEYS */;
INSERT INTO `Person` (`pNo`, `pName`, `phNumber`, `pNumber`, `pAddr`, `pHome`, `pElve`, `Outdate`, `RegDate`, `pMemo`) VALUES
	(1, '임한의', '01012341234', '', '강원 원주시 명륜동 847-3 찾아봐', '주거형태', 'Y', '2019-03-22', '2019-03-20 06:05:54', ''),
	(2, '임', '01089525182', '', '경기 안양시 동안구 달안로 61 1', '단층주택', 'Y', '2019-03-21', '2019-03-20 07:37:19', '');
/*!40000 ALTER TABLE `Person` ENABLE KEYS */;

-- 프로시저 Project.person_check 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `person_check`(
	IN `_phone` VARCHAR(20)

)
BEGIN
SELECT COUNT(*) AS state FROM Person WHERE phNumber = _phone;
END//
DELIMITER ;

-- 테이블 Project.Product 구조 내보내기
CREATE TABLE IF NOT EXISTS `Product` (
  `no` int(11) NOT NULL,
  `name` varchar(10) DEFAULT NULL,
  `upno` int(11) DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 Project.Product:~54 rows (대략적) 내보내기
/*!40000 ALTER TABLE `Product` DISABLE KEYS */;
INSERT INTO `Product` (`no`, `name`, `upno`) VALUES
	(1, '대형', 0),
	(2, '소형', 0),
	(3, '냉장고', 1),
	(4, '세탁기', 1),
	(5, '컴퓨터', 2),
	(6, '가전냉장고', 3),
	(7, '에어컨', 1),
	(8, 'TV', 1),
	(9, '기타대상', 1),
	(10, '프린터', 2),
	(11, '팩시밀리', 2),
	(12, '오디오', 2),
	(13, '소형', 2),
	(14, '휴대폰', 2),
	(15, '컴퓨터 본체', 5),
	(16, '노트북', 5),
	(17, '모니터(CRT)', 5),
	(18, '모니터(LCD)', 5),
	(19, '레이저프린터', 10),
	(20, '비레이저프린터', 10),
	(21, '팩시밀리', 11),
	(22, '오디오(본체)', 12),
	(23, '오디오(스피커)', 12),
	(24, '오디오포터블', 12),
	(25, '음식물처리기', 13),
	(26, '전기히터', 13),
	(27, '전기비데', 13),
	(28, '청소기', 13),
	(29, '선풍기', 13),
	(30, '가습기', 13),
	(31, '다리미', 13),
	(32, '믹서기(주서기)', 13),
	(33, '비디오플레이어', 13),
	(34, '휴대폰', 14),
	(35, '양문형냉장고', 3),
	(36, '김치냉장고(일반)', 3),
	(37, '김치냉장고(스탠드)', 3),
	(38, '와인냉장고', 3),
	(39, '쇼케이스', 3),
	(40, '업소용냉장고', 3),
	(41, '일반세탁기', 4),
	(42, '드럼세탁기', 4),
	(43, '에어컨실내기', 7),
	(44, '에어컨실외기', 7),
	(45, '일체형에어컨', 7),
	(46, '텔레비전(CRT)', 8),
	(47, '텔레비전(LCD,P', 8),
	(48, '프로젝션TV', 8),
	(49, '전기오븐', 9),
	(50, '전기정수기', 9),
	(51, '공기청정기', 9),
	(52, '런닝머신', 9),
	(53, '복사기', 9),
	(54, '전자레인지', 9);
/*!40000 ALTER TABLE `Product` ENABLE KEYS */;

-- 프로시저 Project.pro_first 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `pro_first`(
	IN _Upno INT
)
begin
select * from Product where upno = _Upno;
END//
DELIMITER ;

-- 프로시저 Project.select_orderlist 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `select_orderlist`(
	IN `_phone` VARCHAR(20)


)
BEGIN
	SELECT o.oNo, p.pName, pp.NAME,o.cnt, date_format(o.outdate, '%Y-%m-%d') AS oDate
	  FROM Orderlist AS o
	  inner JOIN Person AS p
	  ON (o.pNo = p.pNo
	  AND p.phNumber = _phone)
	  LEFT OUTER JOIN Product AS pp
	  ON (o.iNo = pp.`no`)
	WHERE o.dleYn = 'N';
END//
DELIMITER ;

-- 프로시저 Project.select_product 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `select_product`(in Upno int, in Name varchar(50))
begin
select d1.name as '대분류', d2.name as '중분류', d3.name as '소분류'
  from Product as d1
  left outer join Product as d2
  on (d1.no = d2.upno)
  left outer join Product as d3
  on (d2.no = d3.upno)
 where d3.upno = Upno and d3.name =Name;
 end//
DELIMITER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
