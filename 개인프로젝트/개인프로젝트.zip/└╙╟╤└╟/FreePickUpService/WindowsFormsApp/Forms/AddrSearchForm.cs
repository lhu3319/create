﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class AddrSearchForm : Form
    {
        public AddrSearchForm()
        {
            InitializeComponent();
            Load += AddrSearchForm_Load;
        }

        private void AddrSearchForm_Load(object sender, EventArgs e)
        {
            
        }
    }
}
